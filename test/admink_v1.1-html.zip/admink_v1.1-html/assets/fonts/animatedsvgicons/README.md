
Animated SVG Icons with Snap.svg
=========

Using SVGs on websites is becoming more and more easy with great libraries like Snap.svg. Today we want to explore what we can do with it and animate some SVG icons as a practical example.

[Article on Codrops](http://tympanus.net/codrops/?p=16851)

[Demo](http://tympanus.net/Tutorials/AnimatedSVGIcons/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)